    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('templates/plugins/src/global/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('templates/plugins/src/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/plugins/src/mousetrap/mousetrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/plugins/src/waves/waves.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/layouts/vertical-light-menu/app.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/assets/js/custom.js')); ?>"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('templates/plugins/src/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/plugins/src/sweetalerts2/sweetalerts2.min.js')); ?>"></script>

    <script>
        const csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;
        // SweetAlert Mixin
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        function _logout() {
            Swal.fire({
                title: 'Logout Sesi',
                text: 'Anda yakin ingin logout dari aplikasi ini?',
                icon: 'question',
                showCancelButton: true,
                cancelButtonText: 'Batalkan',
                confirmButtonText: 'Konfirmasi',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((response) => {
                if (response.isConfirmed) {
                    $('#flogout').submit()
                }
            })
        }
    </script><?php /**PATH D:\Project\laravel\simpatik_web\resources\views/layouts/js.blade.php ENDPATH**/ ?>