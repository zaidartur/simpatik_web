<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('templates/plugins/src/fullcalendar/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('templates/plugins/css/light/fullcalendar/custom-fullcalendar.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('templates/assets/css/light/components/modal.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('templates/plugins/css/dark/fullcalendar/custom-fullcalendar.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('templates/assets/css/dark/components/modal.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
    <div class="middle-content container-xxl p-0">

        <div class="row layout-top-spacing layout-spacing" id="cancel-row">
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="calendar-container">
                    <div class="calendar"></div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Detail Surat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <div class="">
                                    <label class="form-label">Nomor Surat</label>
                                    <input id="event-number" type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-12 mb-3">
                                <div class="">
                                    <label class="form-label">Dari/Kepada</label>
                                    <textarea name="event-title" id="event-title" class="form-control" cols="30" rows="3"></textarea>
                                    
                                </div>
                            </div>
                            <div class="col-md-12 mb-3">
                                <div class="">
                                    <label class="form-label">Isi Surat</label>
                                    <textarea name="event-content" id="event-content" class="form-control" cols="30" rows="5"></textarea>
                                    
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="">
                                    <label class="form-label">Tanggal Surat</label>
                                    <input id="event-date" type="date" class="form-control">
                                </div>
                            </div>
                            
                            <div class="col-md-12">

                                <div class="d-flex mt-4">
                                    <div class="n-chk">
                                        <div class="form-check form-check-primary form-check-inline">
                                            <input class="form-check-input" type="radio" name="event-level" value="Masuk" id="rMasuk" disabled>
                                            <label class="form-check-label" for="rMasuk">Masuk</label>
                                        </div>
                                    </div>
                                    <div class="n-chk">
                                        <div class="form-check form-check-danger form-check-inline">
                                            <input class="form-check-input" type="radio" name="event-level" value="Keluar" id="rKeluar" disabled>
                                            <label class="form-check-label" for="rKeluar">Keluar</label>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn" data-bs-dismiss="modal">Close</button>
                        
                        
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('templates/plugins/src/fullcalendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/plugins/src/uuid/uuid4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/assets/js/custom-fullcalendar.js')); ?>"></script>

    <script>
        //
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\laravel\simpatik_web\resources\views/home.blade.php ENDPATH**/ ?>